# GZA — Masterclass One Shot (iOS Safe)

A single-file challenge to run on GitHub Pages and embed into Wix.

## Features
- One attempt per email (admin can approve a retry)
- 10-minute timer
- Pass/fail if 5 core points are hit
- Coaching notes after every attempt
- Admin panel: approve/revoke, transcripts, CSV/JSON export
- iOS-safe storage (localStorage → cookies → memory)

## Quick Publish (GitHub Pages)
1. Create a public repo (e.g., `gza-one-shot`).
2. Upload `index.html` to the repo root.
3. Go to **Settings → Pages** → set Source to `Deploy from a branch` → Branch `main` and Folder `/ (root)` → Save.
4. Your live URL will be `https://<your-username>.github.io/gza-one-shot/`.
5. In **Wix**: use **Embed a Site (URL)** and paste that URL (not the raw HTML embed).

## Resetting / Testing
- Use a new email (or Gmail plus trick: `name+1@gmail.com`) to test a fresh attempt.
- To allow a retry, open **Admin**, enter the email, click **Approve Retry**.
